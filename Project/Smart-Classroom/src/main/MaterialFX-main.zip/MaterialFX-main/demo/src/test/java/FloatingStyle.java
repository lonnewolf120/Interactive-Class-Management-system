public enum FloatingStyle {
	FLOATING, IFTA
}
